/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.week9jsf.data;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import java.io.Serializable;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

/**
 *
 * @author Maxwell Maia 21236277
 */
@Entity
@Table(name="todoList")
public class Item implements Serializable {

    private static final long serialVersionUID = 1L;    

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    private Integer id;

    @Size(max = 255)
    @Column(name = "category")
    private String category;

    @Lob
    @Size(max = 2550)
    @Column(name = "description", nullable = true)
    private String description;
    
    @Column(name = "priority")
    private Integer priority;
    
    public Item() {
    }

    public Item(Integer id, String category, String description, Integer priority) {
        this.id = id;
        this.category = category;
        this.description = description;
        this.priority = priority;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Item)) {
            return false;
        }
        Item other = (Item) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        
        return (this.category.contentEquals(other.category) && this.description.contentEquals(other.description) && (this.priority.equals(other.priority)));
    }

    @Override
    public String toString() {
        return "Item: id = " + id + ", category = " + category + ", description = " + description + ", priority = " + priority;
    }
    
}
