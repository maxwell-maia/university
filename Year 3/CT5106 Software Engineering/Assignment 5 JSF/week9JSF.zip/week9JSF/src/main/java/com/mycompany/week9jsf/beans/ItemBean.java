/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.week9jsf.beans;

import com.mycompany.week9jsf.data.Item;
import com.mycompany.week9jsf.services.ItemFacade;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

/**
 *
 * @author Maxwell Maia 21236277
 */
@Named("itemBean")
@RequestScoped
public class ItemBean {
    
    @EJB
    private ItemFacade itemFacade;
    
    private long id;
    private String category;
    private String description;
    private int priority;
    
    private Item item;
    
    @PostConstruct
    public void postConstruct() {
        String itemIdParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("itemId");
        if (itemIdParam != null) {
            id = Integer.parseInt(itemIdParam);
            item = itemFacade.find(id);
            category = item.getCategory();
            description = item.getDescription();
            priority = item.getPriority();
        }
    }
    
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public int getPriority() {
        return priority;
    }
    
    public void setPriority(int priority) {
        this.priority = priority;
    }
    
    public String add() {
        Item newItem = new Item();
        newItem.setCategory(category);
        newItem.setDescription(description);
        newItem.setPriority(priority);
        itemFacade.create(newItem);
        System.out.println("added item with description = " + description);
        return "success";
    }

    public String update() {
        item.setCategory(category);
        item.setDescription(description);
        item.setPriority(priority);
        itemFacade.edit(item);
        return "success";
    }
    
    public String delete() {
        itemFacade.remove(item);
        return "success";
    }
}
