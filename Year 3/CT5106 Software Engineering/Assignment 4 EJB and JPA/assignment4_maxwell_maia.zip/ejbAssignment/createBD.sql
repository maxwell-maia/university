

DROP TABLE IF EXISTS `artists`;
CREATE TABLE IF NOT EXISTS `artists` (
  `artistid` int(11) NOT NULL AUTO_INCREMENT,
  `surname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `yob` smallint(6) NOT NULL,
  `biography` longtext NOT NULL,
  PRIMARY KEY (`artistid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artists`
--

INSERT INTO `artists` (`artistid`, `surname`, `firstname`, `yob`, `biography`) VALUES
(1, 'Maia', 'Maxwell', 2002, 'Maxwell Luke Maia (artist)... was an American writer. He won the 1962 Nobel Prize in Literature \"for his realistic and imaginative writings, combining as they do sympathetic humor and keen social perception\". He has been called \"a giant of American letters.\" '),
(2, 'Chanrattanagorn', 'Kirana', 1998, 'Kirana Chanrattanagorn (artist)... was a Welsh-born Scottish poet, fiction writer, military historian, and travel writer. For The Wind on the Moon, a children\'s fantasy novel, he won the 1944 Carnegie Medal from the Library Association for the year\'s best children\'s book by a British subject.');

-- --------------------------------------------------------

--
-- Table structure for table `artworks`
--

DROP TABLE IF EXISTS `artworks`;
CREATE TABLE IF NOT EXISTS `artworks` (
  `artworkid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `medium` varchar(255) NOT NULL,
  `imagename` varchar(255) NOT NULL,
  `artistid` int(11) NOT NULL,
  PRIMARY KEY (`artworkid`),
  KEY `artistid` (`artistid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artworks`
--

INSERT INTO `artworks` (`artworkid`, `title`, `description`, `medium`, `imagename`, `artistid`) VALUES
(1, 'The great hunter', 'She sings her lullaby as she hunts her prey', 'Detailed Digital Art', 'twc', 1),
(2, 'Leon and Chris', 'Chris is stronger because I played him re5', 'Brush', 'twood', 1),
(3, 'Private Angelo', 'A collection of some beautiful jewerelly pieces', 'Brush', 'pa', 2),
(4, 'Ripeness is All', 'Beautiful pendants and earrings', 'Detailed Digital Art', 'ria', 2);
COMMIT;

