/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

/**
 *
 * @author o_molloy
 */
@Entity
@Table(name = "artworks")
@NamedQueries(
{
    @NamedQuery(name = "Artwork.findAll", query = "SELECT b FROM Artwork b")
})
public class Artwork implements Serializable
{

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "artworkid")
    private Integer artworkid;
    
    @Size(max = 255)
    @Column(name = "title")
    private String title;
    
    @Lob
    @Size(max = 2147483647)
    @Column(name = "description")
    private String description;
    
    @Size(max = 255)
    @Column(name = "medium")
    private String medium;
    
    @Size(max = 255)
    @Column(name = "imagename")
    private String imagename;
      
    @JoinColumn(name = "artistid", referencedColumnName = "artistid")
    @ManyToOne
    private Artist artistid;

    public Artwork()
    {
    }

    public Artwork(Integer artworkid)
    {
        this.artworkid = artworkid;
    }

    public Artwork(Integer artworkid, String title, String description, String medium, String imagename, Artist artistid)
    {
        this.artworkid = artworkid;
        this.title = title;
        this.description = description;
        this.medium = medium;
        this.imagename = imagename;
        this.artistid = artistid;
    }



    public Integer getArtworkid()
    {
        return artworkid;
    }

    public void setArtworkid(Integer artworkid)
    {
        this.artworkid = artworkid;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }
    
    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }
    public String getMedium()
    {
        return medium;
    }

    public void setMedium(String medium)
    {
        this.medium = medium;
    }

    public Artist getArtist()
    {
        return artistid;
    }

    public void setArtist(Artist artistid)
    {
        this.artistid = artistid;
    }

    public String getImagename()
    {
        return imagename;
    }

    public void setImagename(String imagename)
    {
        this.imagename = imagename;
    }


    
}
