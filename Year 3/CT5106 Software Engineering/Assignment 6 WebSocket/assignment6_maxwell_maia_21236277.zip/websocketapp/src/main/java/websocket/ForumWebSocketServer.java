/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package websocket;

import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;

/**
 * @author Maxwell Maia, 21236277
 */

@ApplicationScoped
@ServerEndpoint("/forumActions")
public class ForumWebSocketServer
{
    @Inject
    private ForumSessionHandler sessionHandler;
     
    @OnOpen
    public void open(Session session)
    {
        sessionHandler.addSession(session);
    }

    @OnClose
    public void close(Session session)
    {
        sessionHandler.removeSession(session);
    }

    @OnError
    public void onError(Throwable error)
    {
        Logger.getLogger(ForumWebSocketServer.class.getName()).log(Level.SEVERE, null, error);
    }

    @OnMessage
    public void handleMessage(String message, Session session)
    {
        try (JsonReader reader = Json.createReader(new StringReader(message)))
        {
            JsonObject jsonMessage = reader.readObject();

            if ("post".equals(jsonMessage.getString("action")))
            {
                String username = jsonMessage.getString("username");
                String forum = jsonMessage.getString("forum");
                String messageForForum = jsonMessage.getString("message");

                sessionHandler.handlePostMessage(username, forum, messageForForum);
            }
        }    
    }

}
