/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 * @author Maxwell Maia, 21236277
 */

public class ForumMessage
{

    private String username;
    private String forum;
    private String message;

    public ForumMessage(String username, String forum, String message)
    {
        this.username = username;
        this.forum = forum;
        this.message = message;
    }

    public String getUsername()
    {
        return username;
    }

    public String getForum()
    {
        return forum;
    }

    public String getMessage()
    {
        return message;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public void setForum(String forum)
    {
        this.forum = forum;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }
}
