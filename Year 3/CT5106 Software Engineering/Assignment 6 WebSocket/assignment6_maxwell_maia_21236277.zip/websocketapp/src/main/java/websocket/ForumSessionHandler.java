package websocket;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.json.JsonObject;
import jakarta.json.spi.JsonProvider;
import jakarta.websocket.Session;
import model.ForumMessage;

/**
 * @author Maxwell Maia, 21236277
 */

@ApplicationScoped
public class ForumSessionHandler
{
    private final Set<Session> sessions = new HashSet<>();

    public void addSession(Session session)
    {
        sessions.add(session);
    }

    public void removeSession(Session session)
    {
        sessions.remove(session);
    }

    public void postMessage(ForumMessage fm)
    {
        JsonObject messageToPost = createPostMessage(fm);
        sendToAllConnectedSessions(messageToPost);
    }

    public void handlePostMessage(String username, String forum, String message)
    {
        ForumMessage fm = new ForumMessage(username, forum, message);
        postMessage(fm);
    }

    private JsonObject createPostMessage(ForumMessage fm)
    {
        JsonProvider provider = JsonProvider.provider();
        JsonObject messageToPost = provider.createObjectBuilder()
                .add("action", "post")
                .add("username", fm.getUsername())
                .add("forum", fm.getForum())
                .add("message", fm.getMessage())
                .build();
        return messageToPost;
    }

    private void sendToAllConnectedSessions(JsonObject message)
    {
        for (Session session : sessions)
        {
            sendToSession(session, message);
        }
    }

    private void sendToSession(Session session, JsonObject message)
    {
        try
        {
            session.getBasicRemote().sendText(message.toString());
        }
        catch (IOException ex)
        {
            sessions.remove(session);
        }
    }
}
