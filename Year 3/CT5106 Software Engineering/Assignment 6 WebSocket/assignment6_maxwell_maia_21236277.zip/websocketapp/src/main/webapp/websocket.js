//Maxwell Maia, 21236277

var socket = new WebSocket("ws://localhost:8080/WebSocketTest/forumActions");
socket.onmessage = onMessage;

function onMessage(event)
{
    var forumMessage = JSON.parse(event.data);

    if (forumMessage.action === "join")
    {
        handleForumJoin(forumMessage);
    }

    if (forumMessage.action === "post")
    {
        handlePostMessage(forumMessage);
    }
}

function joinForum()
{
    var username = document.getElementById("username").value;
    //The selected forum
    var forum = document.getElementById("forum").value;

    if (username && forum)
    {
        var joinMessage = {
            action: "join",
            username: username,
            forum: forum
        };
        socket.send(JSON.stringify(joinMessage));

        //Hide join form
        document.getElementById("joinForm").style.display = 'none';

        //Show forum form
        document.getElementById("forumForm").style.display = 'block';
        document.getElementById("forumTitle").innerText = forum;
    }
}

function postForumMessage()
{
    var messageInput = document.getElementById("cmessageInput").value;
    if (messageInput) {
        //Check if the WebSocket is open before sending the message
        if (socket.readyState === WebSocket.OPEN) {
            var postMessage = {
                action: "post",
                username: document.getElementById("username").value,
                forum: document.getElementById("forum").value,
                message: messageInput
            };

            socket.send(JSON.stringify(postMessage));

            //Clear input field
            document.getElementById("messageInput").value = '';
        }
        else
        {
            console.error("Error while sending message: WebSocket is not open.");
        }
    }
}

function handleForumJoin(forumMessage)
{
    //Display previous messages when joining a forum
    var forumPosts = document.getElementById("forumPosts");
    forumPosts.innerHTML = forumMessage.messages.join('<br>');
}

function handlePostMessage(forumMessage)
{
    var forumPosts = document.getElementById("textareaForumPosts");

    forumPosts.value += `${forumMessage.username}: ${forumMessage.comment}\n`;
}
