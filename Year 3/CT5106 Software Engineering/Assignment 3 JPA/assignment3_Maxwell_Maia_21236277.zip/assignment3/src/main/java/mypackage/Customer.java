/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mypackage;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 *
 * @author Maxie
 */
@Entity
@Table(name = "Customer")
public class Customer implements Serializable {
            
    @Id
    @Column(name="cusid")
    private int cusid;
    @Column(name = "name")
    private String name;
    @Column(name="phone")
    private String phone;
    @Column(name="email")
    private String email;
    @Column(name="country")
    private String country;
    @Column(name="postCode")
    private String postCode;
    @Column(name="creditLimit")
    private double creditLimit;
    
    public Customer()
    {
        
    }
    
    public Customer(int cusid, String name, String phone, String email, String country, String postCode, long creditLimit)
    {
        this.cusid = cusid;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.country = country;
        this.postCode = postCode;
        this.creditLimit = creditLimit;
    }
}
