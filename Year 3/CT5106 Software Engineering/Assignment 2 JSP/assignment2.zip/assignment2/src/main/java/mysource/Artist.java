//Maxwell Maia
//21236277

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mysource;

/**
 *
 * @author Maxie
 */
public final class Artist
{
    private String surname;
    private String firstName;
    private String nationality;
    private String birthYear;
    private String deathYear;
    private String biography;
    private String photoURL;
    
    public Artist()
    {
        
    }
    
    public Artist(String surname, String firstName, String nationality, String birthYear, String deathYear, String biography, String photoURL)
    {
        setSurname(surname);
        setFirstName(firstName);
        setNationality(nationality);
        setBirthYear(birthYear);
        setDeathYear(deathYear);
        setBiography(biography);
        setPhotoURL(photoURL);
    }

    //Getters and Setters
    public String getSurname()
    {
        return surname;
    }

    public void setSurname(String surname)
    {
        this.surname = surname;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality)
    {
        this.nationality = nationality;
    }

    public String getBirthYear()
    {
        return birthYear;
    }

    public void setBirthYear(String birthYear)
    {
        this.birthYear = birthYear;
    }

    public String getDeathYear()
    {
        return deathYear;
    }

    public void setDeathYear(String deathYear)
    {
        this.deathYear = deathYear;
    }

    public String getBiography()
    {
        return biography;
    }

    public void setBiography(String biography)
    {
        this.biography = biography;
    }

    public String getPhotoURL()
    {
        return photoURL;
    }

    public void setPhotoURL(String photoURL)
    {
        this.photoURL = photoURL;
    }
    
    
}
