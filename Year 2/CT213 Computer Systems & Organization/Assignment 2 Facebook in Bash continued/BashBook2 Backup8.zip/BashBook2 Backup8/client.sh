#!/bin/bash

request_is_valid=false
prev_input="zzzzzzzzzzzzzzz"
#input="wasssssup"

request="no request stored"
prev_request="no previous request stored"

flag=0

#checking that a parameter has been given
if [ $# -eq 1 ]; then
	id=$1
	echo "client id: $id (not neccesarily an existing user id)"
	
	#I am a client with id=$id. I want to recieve information from the server in the pipe called $id.pipe
	#Create pipe to receive data on
	mkfifo $id.pipe
	
	#Bonus mark question
	## deletes the pipe when ctrl+c is pressed
	trap "rm $id.pipe" EXIT
	
	#Remove pipe
	#rm $id.pipe
	
	#endless loop
	while true; do
		#read a request
		read req args
		
		#Requests. $req $id $args
		# $req is a command e.g. create/add/post/display
		# $id is obtained when starting the client.sh script and is automatically added when sending the request to the server. so the user does not have to type it.
		
		
		#Example requests that a user can type
		
		#create
		#add friendname
		#post friendname message
		#display userId
		
		
		#TODO the content of the below if statement (the content of the if statement is pretty much the whole rest of the script) should run if: the request is "well formed". This is not specific in the assignment doc. However In this code I know that the requirements are as follows: 1. req always needs to be present. 2. args needs to be present if req = display/add/post
		
		#Code here
		request_is_valid=true
		
		##Bonus. QoL, make it so that when req = display and args is empty, echo $req $id $id > server.pipe
		#if [ ??? ]; then
		#	echo $req $id $id > server.pipe
		#fi
		
		#if the request is well formed...
		if [ "$request_is_valid" = true ]; then
			
			#Send the request to the server. echo into server.pipe
			echo "Request is well formed, sending to server."
			#request="$req $id $args"
			
			request="$req $id $args"
			
			#Code to prevent the program from hanging when the same request is made to the server twice in a row. (Since the server ignores the same request as the one before[so that it doesn't spam commands in a loop]. we have to send a different request, clear the $id.pipe and then our intended request can be sent)
			if [ "$prev_request" == "$request" ]; then
		 	 echo "the requests are the same, $request/$prev_request"
		 # update server pipe with refresh message
		 	 echo "refresh $id" > server.pipe # refresh command because i want you (server) to update your prev_input so you don't skip my next command"
		 	 echo "sent to server: refresh $id"
		 	 echo "before reading refresh, input:$input"
		 	 read input < $id.pipe
		 	 echo "should be refresh success response from server:$input"
		 	 #Hello reader. Below is the line of code I needed. I spent aaaa maybe 3 hours trying to find this line. There was an empty character in the $id.pipe for some reason. One of those coding HAHA moments. Goodnight.
		 	 #remove invisible character from pipe
		 	 read input < $id.pipe
		 	 #echo "$input"

	#TODO remove uneccesary echos (used in debugging)
	#TODO add syncro to post, add and display. ask maxwell. DONT ASK MAXWELL HE DID IT! LIKE A BOSS and thats why I had to send it to you later

	 		else
	 	 	 echo "the requests are the different, $request/$prev_request"
	 	 #flag=0
	 		fi
	 
	 
	 		
	 
	 		echo $request
			echo $req $id $args
			echo $req $id $args > server.pipe #this works
			prev_request="$req $id $args"
		else
			echo "Request not well formed. (requests have the form: req args)"
		fi  #end of if [ isValidRequest ]
		
		
		#SERVER REPLY
		
		
		##Remove
		#constantly read from the server pipe.
	#read input < $id.pipe; echo $input
	#read input < $id.pipe; echo $input  #PROBLEM, Waiting for server response before the client is allowed to continue. I am trying to fix that with an &
	
	
	##Remove
	#if the previous one is empty, then send what you have now
	#if [ -z $prev_input ]; then
	#	prev_input=$input
	#fi
	
	##Remove
	##Useful. just need to add a SET PREV INPUT TO OLD INPUT
	#if the previous one is not the same as the current, then send what you have now AND set prevous to current
	#echo "$prev_input, $input"
	#if [ "$prev_input" != "$input" ]; then
	#	#Need to read
	#	echo $input	
	#	
	#fi
	
	##Remove Ignore request to leave comment because its been moved.
	##LEAVE COMMENTED BELOW IN FINAL CUT BECAUSE IF ITS NECESSARY THAT A USER CAN ENTER THE SAME COMMAND TWICE IN A ROW THEN THIS WILL AWARD SOME MARKS MAYBE
	##TRYING TO GET SAME COMMAND TWICE IN A ROW NOT CRASH THE CLIENT
	#I have an issue: when the user enters the same command as before (and no other user has entered a command), the user updates the server.pipe (as its supposed to) but this update didn't change what was in the pipe (because the last command was the exact same). The server only runs a command that was different to the last one in the pipe. So the server does not run any command and the $id.pipe remains empty and this client sits and wait for an input at the "read input < $id.pipe" near line 101. and it gets stuck
	#The program works fine if a user does not submit the same request twice in a row.
	# Below is the code that I made to try avoid this issue but it does not work

	

	#WAS HERE

	# if i have just sent the same command as before
	#if [ $flag -eq 1 ]; then
		
		
		
	#else
	#	echo "flag 0. there i think prev is different and we can continue without error. Cool, continue with code."
		
	#fi
	##MORE COMMENTED CODE RELATED TO SAME COMMAND TWICE IN A ROW CAN BE FOUND BELOW.
	
##Remove all debugging code
	#Get the reply from the server
	echo "Getting reply from server that I know is good"
	echo "This may not be accurate. This is fine. Previous input (before reading) ('refresh success' if doing a duplicate):$input"
	read input < $id.pipe
	echo "This may not be accurate. This is fine. After reading (should be what I want to print) $input"
	
	#If the input is a signal that a wall (file) is being sent over the pipe, read and print the pipe until it says end of the file.
	if [ "$input" == "start_of_the_file" ]; then
	echo "$args's wall:"
	 while [ "$input" != "end_of_the_file" ]; do
		 read input < $id.pipe #reading again might skip start?
		 if [ "$input" != "end_of_the_file" ]; then
		 	#TODO Do the TODO below to understand this one. check if $input is equal to error code and echo approprate human readble. #Server response -> human readable (for display)
			 echo "$input"
		 fi
	done
	
	else
	#single line input (single line response from server, i.e. NOT display)

	
	#TODO #Server response -> human readable
	#e.g. if [ "$input" == "nok: user $id does not exist" ]; then
	#	echo Sorry, we couldn't find a user called $id. Try creating an account by typing "create"!
	#fi
	#Do this for every response message
	#the input variable right here contains the response message FROM the scripts create, post, add.
	
	#Note! The display function returns its errors inside the wall. See the TODO above.
	
	# Code that echos the correct response here
	#echo $input #Echo server response for my debugging
	
	##debug. remove.
	echo "Server response to request: '$input'"
	
	
	##Remove
	##COMMENTED CODE. TRYING TO GET SAME COMMAND TWICE IN A ROW NOT CRASH THE CLIENT
	# if the previous input (request) is not the same as the current, then send what you have now AND set prevous to current
	  #echo "$prev_input, $input"
	# might be the same as the previous loop of this script, so don't run the command twice
	 #if [ "$prev_input" == "$input" ]; then
	#	 echo "*EQUAL TO PREV prev=$prev_input, current=$input"
	#	 echo $input
	#	 prev_input=$input
	#	 flag=1
	#	 
	 #else
	 #	 echo "inputs are the different"
	 #	 flag=0
	 #fi
	 
	 #echo "END OF EXEC, SHOULD BE EQUAL input = prev input $prev_input, $input"
	 
	 
	 
	fi
	
	
	
	
	
	##Remove
	#if [ "$input" != "end_of_file" ]; then
	#	#Need to read
	#	#echo $input
	#	read input < $id.pipe; echo $input
	#fi
		
		
		
		
	#main while loop end		
	done
	
	
fi

echo "nok: no client identifier provided or too many parameters provided"
	exit 1

