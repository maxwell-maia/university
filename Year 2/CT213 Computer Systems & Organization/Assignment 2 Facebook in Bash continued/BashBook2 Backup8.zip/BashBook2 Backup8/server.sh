#!/bin/bash

echo "Initilizing server..."
echo ""

#set up the server.pipe if it hasn't been set up already
mkfifo server.pipe
echo server.pipe has been created.

echo ""

#if [ ! -p "server.pipe" ]; then
	#mkfifo server.pipe
	#echo server.pipe has just been created.
#else
	#echo server.pipe has already been created.
#fi


echo "1. Make sure to *REMOVE CONTENTS OF server.pipe* manually before starting the server."
echo "2. AND *REMOVE ANY LOCKS AND "'$'"id.pipes* from the directory."
echo "[Locks and "'$'"id.pipes are removed automatically during the normal operation of the server (including stopping the server) however your server's computer system crashing may cause locks and pipes to be left over. These could cause incorrect commands to be run and could cause the program to hang.]"
echo ""

#Clear the server.pipe#TODO
#I can't find code to do this manually and I dont want to read until empty because I don't want my program to hang. *Clear the server.pipe manually every time you launch the server*.
#dd if=myfifo iflag=nonblock of=/dev/null
#open("myfifo", O_RDONLY|O_NONBLOCK)

#read once [test]
#read input < server.pipe
#echo $input

#constantly read from this pipe.
# see below I think this code belongs there in that while. but right now it loops.

#Do I need read the error message that was just echoed by the create.sh script and send that in the (client)id.pipe? Or Do I pass the client id to the command e.g. create.sh and then the create.sh script sends it to the pipe too?

#What happens if 2 client processes send a request to the pipe at the same time. The pipe is not a queue. One request will be lost. So need to make it so that a client cannot send a request until it has been executed by the server?

prev_input="zzzzzzzzzzzzzzz"

while true; do
	# next 3 comments from assignment 1
	# read a new command 
	# It does not matter if the user gives less or more arguments at this point
	#read command id id2 message
	
	#constantly read from the server pipe.
	
	read input < server.pipe
	
	#echo $input
	
	#if the previous one is empty, then send what you have now
	#if [ -z $prev_input ]; then
	#	prev_input=$input
	#fi
	#if the previous one is not the same as the current, then send what you have now AND set prevous to current
	#echo "$prev_input, $input"
	
	# if input is different, understand the request *AND execute it. *This is assuming the request is well formed, which it is (done in the client script).
	
	#Only caviat is that if the same user sends the same request twice it will not run. Solution: maybe the user needs to send a request that does nothing after each request.
	if [ "$prev_input" != "$input" ]; then
		#Need to read "command id id2 message" variables from what comes in the pipe
		#echo $input | (read command id id2 message)
		read command id id2 message <<< $input
		
	##Server status messages
	echo "==========================================="
	echo "Request recieved from server.pipe. Interpretting request."
	echo "Request='$input'"
	echo "VARIABLES FROM REQUEST:"
	echo "command: $command"
	echo "id: $id"
	#IS id in the client script different from the id of the user that the client uses? I guess thats a design decision. The client id will become the user id. when the client requests to create a user, the server creates a user with the client's id, so they kind of become the same.
	echo "id2: $id2"
	echo "message: $message"
	
	##Remove
	#Make this run one time per request
	
	##Remove
	# check if $id is not empty
	#if [ -n $id ]; then
	
	#Run the command accociated with the request.
	echo "Executing command with parameters..."
	#SYNCRONISATION AND COMMANDS
		case $command in
			create)
				#execute the command create and send the standard output in the user $id pipe
				
				
				#The echos can be removed in server implementation for better performance. *The echos in the line below are part of the critical section because another request might change the $id*, the echos are there for debugging and demonstration purposes.
				./acquire.sh "$id"_lock; echo "Executing create command for user: '$id'"; ./create.sh $id > $id.pipe; echo "Create command completed, returning output to user: '$id'"; ./release.sh "$id"_lock & #the & means that the program will continue running, it will not wait for this line to finish. the line will finish on it's own and return the input to the user on its own. This means that the server can take requests from multiple people at once. (This is why we need syncronisation)!
				;;
			add)
			#Echos can be removed for performance.
			
				#Cannot lock the same id twice
				#Check that the id's are different
				if [ "$id" != "$id2" ]; then
					#Lock 2 clients
					./acquire.sh "$id"_lock; ./acquire.sh "$id2"_lock; echo "Executing add command for user: '$id'"; ./add.sh $id $id2 > $id.pipe; echo "Add command completed, returning output to user: '$id'"; ./release.sh "$id2"_lock; ./release.sh "$id"_lock &
				else
					#Only lock one client
					./acquire.sh "$id"_lock; echo "Executing add command for user: '$id'"; ./add.sh $id $id2 > $id.pipe; echo "Add command completed, returning output to user: '$id'"; ./release.sh "$id"_lock &
				fi
				
				;;
			post)
			#Echos can be removed for performance.
			
				#Cannot lock the same id twice
				#Check that the id's are different
				if [ "$id" != "$id2" ]; then
					#Lock 2 clients
					./acquire.sh "$id"_lock; ./acquire.sh "$id2"_lock; echo "Executing post command for user: '$id'"; ./post.sh $id $id2 "$message" > $id.pipe; echo "Post command completed, returning output to user: '$id'"; ./release.sh "$id2"_lock; ./release.sh "$id"_lock &
				else
					#Only lock one client
					./acquire.sh "$id"_lock; echo "Executing post command for user: '$id'"; ./post.sh $id $id2 "$message" > $id.pipe; echo "Post command completed, returning output to user: '$id'"; ./release.sh "$id"_lock &
				fi
				
				
				;;
			display)
			
				##Remove
				#wallToClient="The wall is empty."
				# inform the client that we will start senting the content of the wall
				#execute the display command and save the result in a variable
				#clientWall=`./display.sh $id`
				
				
				#DISPLAY WALL and send output to client that requested it (id)
				#Do not remove the echo lines. Used to tell the client when to start and when to stop reading a bunch of lines from the pipe
				#The "echo "result: returning wall to '$id.pipe'";" bit can be removed for performance reasons.
				
				##Note id2 is the user we want to see the wall of
				
				#Cannot lock the same id twice
				#Check that the id's are different
				if [ "$id" != "$id2" ]; then
					#Lock 2 clients
					./acquire.sh "$id"_lock; ./acquire.sh "$id2"_lock; echo "start_of_the_file" > $id.pipe; ./display.sh $id2 > $id.pipe; echo "end_of_the_file" > $id.pipe; echo "result: returning wall to '$id.pipe'"; ./release.sh "$id2"_lock; ./release.sh "$id"_lock &
				else
					#Only lock one client
					./acquire.sh "$id"_lock; echo "start_of_the_file" > $id.pipe; ./display.sh $id2 > $id.pipe; echo "end_of_the_file" > $id.pipe; echo "result: returning wall to '$id.pipe'"; ./release.sh "$id"_lock &
				fi
				
				
				
				
				
				
								
				##Remove
				# send the content of the wall stored in clientWall to the client line by line
				#IFS=$'\n' # changing the delimiter to a new line
				#for line in $clientWall; do
				#	echo $line < $id.pipe
				#	#wallToClient=$'
				#done
				#IFS=$' ' # bring back the delimiter into its original state (i.e., space)
				
				##Need to build up walltoclient. just outputting "The wall is empty."
				#echo $wallToClient
				#echo $wallToClient > $id.pipe
				;;
			refresh)
				#Special command to resfresh the item in the server.pipe.
				#This allows the same user to send the same command twice in a row.
				#All it needs to do is tell the user that the refresh is successful and complete. This will change the prev_input variable too so that the next command will run. (the same command doesn't run twice because otherwise the server would coninously spam the most recent command as it is in a loop.
				echo "result: refresh success. Sending response to user."
				echo "refresh success" > $id.pipe
				
				;;
			*)
				echo "result: invalid command. Sending response to user."
				echo "These are the only valid commands: {create|add|post|display}" > $id.pipe
				
		esac
		
		prev_input=$input
		
		##Remove
		#echo > $id
		
		##Remove
		#set the pipe to empty after every command
		#echo "" > server.pipe

	fi
	
	##Remove
	#echo > server.pipe
	
	
done
exit 0

