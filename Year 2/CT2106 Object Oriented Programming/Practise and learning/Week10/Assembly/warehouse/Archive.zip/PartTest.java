package warehouse;

/**
 * PartTest is used to write test code
 * for the Assembly Part classes.
 * @author (conor hayes)
 * @version (Nov 2nd)
 */
public class PartTest
{
   
 public int costTest(){
     // TODO :Create the test code here
     return 0;
 }
 
 
 public static void main(String[] args)
 {
        // put your code here
        PartTest partTest = new PartTest();
        int value = partTest.costTest();
 }
}
